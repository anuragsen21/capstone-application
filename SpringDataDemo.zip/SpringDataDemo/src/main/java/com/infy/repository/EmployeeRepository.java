package com.infy.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.infy.entity.Employee;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Integer>{
	List<Employee> findByEmpCity(String name);
	List<Employee> findByEmpNameLike(String likePattern);
	
	List<Employee> findByEmpSalaryGreaterThan(Integer salary);
	List<Employee> findByEmpSalaryGreaterThanEqual(Integer salary);
	List<Employee> findByEmpSalaryBetween(Integer startSalary, Integer endSalary);
	
	Employee findByUserNameAndPassword(String username, String password);
}
