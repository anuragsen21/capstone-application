package com.infy.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.dto.EmployeeDTO;
import com.infy.entity.Employee;
import com.infy.repository.EmployeeRepository;

@Service
public class EmployeeService {
	@Autowired
	private EmployeeRepository repo;
	public void insert(EmployeeDTO dto) {
		Employee entity = new Employee();
		entity.setEmpId(dto.getEmpId());
		entity.setEmpName(dto.getEmpName());
		entity.setEmpCity(dto.getEmpCity());
		entity.setEmpSalary(dto.getEmpSalary());
		repo.save(entity);
	}
	public void getEmpNameById(int id) throws Exception{
		Optional<Employee> opt = repo.findById(id);
		Employee e = opt.orElseThrow(() -> new Exception("Employee with id " + id + "not found !!!"));
		System.out.println(e.getEmpName());
	}
	public void getAllEmployees() {
		List<Employee> list = repo.findAll();
		list.stream().forEach(System.out::println);
	}
	public void updateEmployee(int id, String city) throws Exception{
		Optional<Employee> opt = repo.findById(id);
		Employee e = opt.orElseThrow(() -> new Exception("Employee with id " + id + "not found !!!"));
		e.setEmpCity(city);
		repo.save(e);
	}
	public void DeleteEmployee(int id) throws Exception{
		Optional<Employee> opt = repo.findById(id);
		Employee e = opt.orElseThrow(() -> new Exception("Employee with id " + id + " not found !!!"));
		repo.delete(e);
		repo.deleteById(id);
	}
	
	public void getAllEmployeesOfParticularCity(String city) {
		List<Employee> list = repo.findByEmpCity(city);
		list.stream().forEach(System.out::println);
	}
	public void getAllEmployeesOfNameLike(String name) {
		List<Employee> list = repo.findByEmpNameLike(name);
		list.stream().forEach(System.out::println);
	}
	public void getAllEmployeesOfSalaryGreaterThan(Integer salary) {
		List<Employee> list = repo.findByEmpSalaryGreaterThan(salary);
		list.stream().forEach(System.out::println);
	}
	public void getAllEmployeesOfSalaryGreaterThanEqual(Integer salary) {
		List<Employee> list = repo.findByEmpSalaryGreaterThanEqual(salary);
		list.stream().forEach(System.out::println);
	}
	public void getAllEmployeesOfSalaryBetween(Integer startSalary, Integer endSalary) {
		List<Employee> list = repo.findByEmpSalaryBetween(startSalary, endSalary);
		list.stream().forEach(System.out::println);
	}
	public Employee doLoging(String username, String password){
		return repo.findByUserNameAndPassword(username, password);
	}
}
