package com.infy;

import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


import com.infy.dto.EmployeeDTO;
import com.infy.entity.Employee;
import com.infy.service.EmployeeService;

@SpringBootApplication
public class SpringDataDemoApplication implements CommandLineRunner{
	@Autowired
	private EmployeeService service;
	
	public static void main(String[] args) {
		SpringApplication.run(SpringDataDemoApplication.class, args);
	}
	@Override
	public void run(String... args) throws Exception {
		Scanner scan 	= new Scanner(System.in);
		System.out.println("Username : ");
        String username = scan.nextLine();
        System.out.println("Password : ");
        String password = scan.nextLine();
        Employee emp = service.doLoging(username, password);
        if(emp != null) {
        	System.out.println("Login Success !!!");
        }else {
        	System.out.println("No such username found !!!");
        }
        
        
//        sc.hasNextInt() ? "(int) " + sc.nextInt() :
//            sc.hasNextLong() ? "(long) " + sc.nextLong() :  
//            sc.hasNextDouble() ? "(double) " + sc.nextDouble() :
//            sc.hasNextBoolean() ? "(boolean) " + sc.nextBoolean() :
		
//		String name 	= "Sen Anurag";
//		Integer id 		= 1191602;
//		Integer sal		= 600;
//		String city		= "Kolkata";
//		EmployeeDTO dto	= new EmployeeDTO(name, id, sal, city);
//		service.insert(dto);
		
//		service.getAllEmployeesOfParticularCity("Kolkata");
//		service.getEmpNameById(1191601);
//		service.getAllEmployees();
//		service.updateEmployee(1191601, "Guwahati");
//		service.getAllEmployeesOfNameLike("%Anurag%");
        
        
//		service.getAllEmployeesOfSalaryGreaterThan(salaryInput);
//		service.getAllEmployeesOfSalaryGreaterThanEqual(salaryInput);
//		service.getAllEmployeesOfSalaryBetween(salaryInput, salaryInputLast);
		scan.close();
	}

}
