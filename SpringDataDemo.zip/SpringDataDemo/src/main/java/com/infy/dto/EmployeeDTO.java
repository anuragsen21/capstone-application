package com.infy.dto;

public class EmployeeDTO {
	private Integer empId;
	private String empName;
	private String empCity;
	private Integer empSalary;
	public EmployeeDTO(String name, Integer id, Integer sal, String city) {
		// TODO Auto-generated constructor stub
		super();
		this.empId 		= id;
		this.empName	= name;
		this.empCity	= city;
		this.empSalary	= sal;
	}
	public Integer getEmpId() {
		return empId;
	}
	public void setEmpId(Integer empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmpCity() {
		return empCity;
	}
	public void setEmpCity(String empCity) {
		this.empCity = empCity;
	}
	public Integer getEmpSalary() {
		return empSalary;
	}
	public void setEmpSalary(Integer empSalary) {
		this.empSalary = empSalary;
	}

}
